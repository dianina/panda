### Summary

Please summarize your issue here.

### Steps to Reproduce

1. Step one
2. Step two
3. ...

### Additional info

- Shoelace version:
- Affected browsers:

---

Note: This issue tracker is ONLY for bug reports and feature requests. If this is a personal support issue, please ask on [Stack Overflow](https://stackoverflow.com/tags/shoelacecss).
