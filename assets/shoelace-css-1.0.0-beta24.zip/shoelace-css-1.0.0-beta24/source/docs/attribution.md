---
layout: default.html
title: Attribution
description: Special thanks to the following individuals and organizations.
---

## Attribution

Special thanks to the following individuals and organizations for their contributions to Shoelace.css.

- [Cory LaViska](https://twitter.com/claviska) – for creating this project.
- [Adam K Olson](https://twitter.com/adamkolson) – for designing the logo with a single shoelaces.
- [Bootstrap](https://getbootstrap.com/) – for inspiration and an amazing grid system.
- [KeyCDN](https://keycdn.com/) – for providing an awesome CDN service.
- [GitHub](https://github.com/) – for hosting this and many other open source projects.
- [Surreal CMS](https://www.surrealcms.com/) – for sponsoring development.
